import logging
import asyncio
from datetime import datetime, time
import pytz
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes
import gspread
from google.oauth2.service_account import Credentials
import json
import os

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# === SOZLAMALAR ===
BOT_TOKEN = os.environ.get("BOT_TOKEN", "")
SPREADSHEET_ID = "1zEIXv-r467FzdEetmR6qhEQSoUstNhlK"
GROUP_ID = -1002761583094
TIMEZONE = "Asia/Tashkent"
BOMDOD_START_H, BOMDOD_START_M = 3, 0
BOMDOD_END_H, BOMDOD_END_M = 5, 35

# === GOOGLE SHEETS ===
def get_sheet():
    creds_json = os.environ.get("GOOGLE_CREDENTIALS", "{}")
    creds_dict = json.loads(creds_json)
    scopes = [
        "https://www.googleapis.com/auth/spreadsheets",
        "https://www.googleapis.com/auth/drive"
    ]
    creds = Credentials.from_service_account_info(creds_dict, scopes=scopes)
    client = gspread.authorize(creds)
    sheet = client.open_by_key(SPREADSHEET_ID)
    try:
        worksheet = sheet.worksheet("Bomdod")
    except:
        worksheet = sheet.add_worksheet(title="Bomdod", rows=1000, cols=10)
        worksheet.append_row(["Ism Familiya", "Telegram Username", "Sana", "Vaqt"])
    return worksheet

# === HOLAT ===
user_states = {}
registered_today = set()

def is_bomdod_time():
    tz = pytz.timezone(TIMEZONE)
    now = datetime.now(tz)
    start = now.replace(hour=BOMDOD_START_H, minute=BOMDOD_START_M, second=0)
    end = now.replace(hour=BOMDOD_END_H, minute=BOMDOD_END_M, second=0)
    return start <= now <= end

def get_today():
    tz = pytz.timezone(TIMEZONE)
    return datetime.now(tz).strftime("%Y-%m-%d")

# === START ===
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    today = get_today()

    if not is_bomdod_time():
        tz = pytz.timezone(TIMEZONE)
        now = datetime.now(tz)
        await update.message.reply_text(
            f"Assalomu alaykum! 🌙\n\n"
            f"Hozir soat {now.strftime('%H:%M')}.\n"
            f"Bomdod yo'qlama vaqti: 03:00 — 05:35.\n\n"
            f"O'sha vaqtda keling! ✅"
        )
        return

    if f"{user_id}_{today}" in registered_today:
        await update.message.reply_text("Siz bugun allaqachon qatnashgansiz! ✅\nJazakAllahu khayran! 🤲")
        return

    user_states[user_id] = "waiting_name"
    await update.message.reply_text(
        "Assalomu alaykum! 🌅\n\n"
        "Bomdod namozi yo'qlamasiga xush kelibsiz!\n\n"
        "Iltimos, to'liq *Ism Familiyangizni* yozing:",
        parse_mode="Markdown"
    )

# === XABAR ===
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    today = get_today()

    if user_states.get(user_id) != "waiting_name":
        await update.message.reply_text("Yo'qlama uchun /start bosing. 👋")
        return

    if not is_bomdod_time():
        await update.message.reply_text("Vaqt o'tib ketdi. Ertaga 03:00 da keling! 🌙")
        user_states.pop(user_id, None)
        return

    if f"{user_id}_{today}" in registered_today:
        await update.message.reply_text("Siz bugun allaqachon qatnashgansiz! ✅")
        user_states.pop(user_id, None)
        return

    name = update.message.text.strip()
    if len(name) < 3:
        await update.message.reply_text("Iltimos, to'liq ism familiyangizni yozing. 📝")
        return

    context.user_data["name"] = name
    keyboard = [
        [InlineKeyboardButton("✅ Bomdod namozini o'qidim", callback_data="confirmed")],
        [InlineKeyboardButton("❌ Bekor qilish", callback_data="cancel")]
    ]
    await update.message.reply_text(
        f"Ism: *{name}*\n\nBomdod namozini o'qiganingizni tasdiqlaysizmi?",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

# === TUGMA ===
async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    today = get_today()

    if query.data == "cancel":
        user_states.pop(user_id, None)
        await query.edit_message_text("Bekor qilindi. 🌙")
        return

    if query.data == "confirmed":
        if f"{user_id}_{today}" in registered_today:
            await query.edit_message_text("Siz bugun allaqachon qatnashgansiz! ✅")
            return
        if not is_bomdod_time():
            await query.edit_message_text("Vaqt o'tib ketdi. Ertaga keling! 🌙")
            return

        name = context.user_data.get("name", "Noma'lum")
        username = query.from_user.username or "username yoq"
        tz = pytz.timezone(TIMEZONE)
        now = datetime.now(tz)
        date_str = now.strftime("%Y-%m-%d")
        time_str = now.strftime("%H:%M")

        try:
            sheet = get_sheet()
            sheet.append_row([name, f"@{username}", date_str, time_str])
            registered_today.add(f"{user_id}_{today}")
            user_states.pop(user_id, None)
            await query.edit_message_text(
                f"✅ *Qayd etildi!*\n\n"
                f"👤 {name}\n📅 {date_str}\n⏰ {time_str}\n\n"
                f"JazakAllahu khayran! 🤲",
                parse_mode="Markdown"
            )
        except Exception as e:
            logger.error(f"Sheets xato: {e}")
            await query.edit_message_text("Xato yuz berdi. Qayta urinib ko'ring. 🔄")

# === STATISTIKA ===
async def stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    today = get_today()
    count = sum(1 for k in registered_today if k.endswith(f"_{today}"))
    await update.message.reply_text(
        f"📊 *Bugungi statistika*\n\n📅 {today}\n✅ {count} kishi",
        parse_mode="Markdown"
    )

# === GURUHGA XABAR ===
async def send_bomdod_reminder(context: ContextTypes.DEFAULT_TYPE):
    try:
        me = await context.bot.get_me()
        await context.bot.send_message(
            chat_id=GROUP_ID,
            text=(
                "🌅 *Bomdod namozi vaqti!*\n\n"
                "Assalomu alaykum! 🤲\n\n"
                f"Botga kiring va belgilang: @{me.username}\n\n"
                "⏰ 03:00 — 05:35\n"
                "Alloh qabul qilsin! 🌙"
            ),
            parse_mode="Markdown"
        )
    except Exception as e:
        logger.error(f"Guruh xabar xato: {e}")

# === MAIN ===
def main():
    if not BOT_TOKEN:
        logger.error("BOT_TOKEN topilmadi!")
        return

    app = Application.builder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("stats", stats))
    app.add_handler(CallbackQueryHandler(handle_callback))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    tz = pytz.timezone(TIMEZONE)
    app.job_queue.run_daily(
        send_bomdod_reminder,
        time=time(3, 0, tzinfo=tz)
    )

    logger.info("Bot ishlamoqda!")
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    main()
